@echo off
:: Double-clique sur ce fichier pour ouvrir le launcher.
:: Il execute Launcher.ps1 (doit rester dans le meme dossier).

:: Se place dans le dossier ou se trouve ce .bat
cd /d "%~dp0"

if not exist "%~dp0Launcher.ps1" (
    echo.
    echo ============================================================
    echo Launcher.ps1 est INTROUVABLE dans ce dossier :
    echo %~dp0
    echo.
    echo Verifie que le fichier s'appelle exactement "Launcher.ps1"
    echo ^(pas "Launcher.ps1.txt"^) et qu'il est bien a cote de ce .bat.
    echo.
    echo Contenu actuel du dossier :
    dir /b "%~dp0"
    echo ============================================================
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launcher.ps1"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo ============================================================
    echo Le script s'est arrete avec une erreur ^(code %EXITCODE%^).
    echo Regarde le message d'erreur affiche au-dessus.
    echo ============================================================
)

echo.
pause
