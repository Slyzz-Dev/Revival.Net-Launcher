# ==========================================================
#  Launcher.ps1 - customizable terminal launcher (game-style menu)
#  Edit the sections marked [CUSTOMIZATION] below.
# ==========================================================

# Move to the folder where this script is located
Set-Location -Path $PSScriptRoot

# ================= [CUSTOMIZATION] =================
$AppName      = "Revival.Net Launcher"  # name shown in the banner
$GamePath     = "$env:LOCALAPPDATA\Revival.Net\ReadME.txt"  # exe launched by option 2
$DownloadUrl  = "https://github.com/Slyzz-Dev/Revival.Net-Launcher"   # ← put your real GitHub Releases link here
$PatchnotesUrl= "https://example.com/patchnotes" # (unused for now)

# Available colors: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta
# DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White
$TitleColors  = @("White")
$BorderColor  = "DarkCyan"
$MenuNumColor = "White"
$OkColor      = "Green"
$ErrColor     = "Red"
# =====================================================

$Host.UI.RawUI.WindowTitle = $AppName

function Write-ColoredTitle {
    param([string]$Text)
    $i = 0
    foreach ($ch in $Text.ToCharArray()) {
        if ($ch -eq " ") {
            Write-Host " " -NoNewline
        } else {
            $color = $TitleColors[$i % $TitleColors.Count]
            Write-Host $ch -NoNewline -ForegroundColor $color
        }
        $i++
    }
    Write-Host ""
}

function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-ColoredTitle $AppName
    Write-Host ""
    Write-Host "Sorry, the game hasn't been released yet." -ForegroundColor $ErrColor
    Write-Host ""

    if (Test-Path $GamePath) {
        Write-Host -NoNewline "Status : "
        Write-Host "INSTALLED" -ForegroundColor $OkColor -NoNewline
        Write-Host "  ($GamePath)"
    } else {
        Write-Host -NoNewline "Status : "
        Write-Host "NOT INSTALLED" -ForegroundColor $ErrColor
    }
    Write-Host ""

    Write-Host -NoNewline "1. " -ForegroundColor $MenuNumColor
    Write-Host "Download / install"
    Write-Host -NoNewline "2. " -ForegroundColor $MenuNumColor
    Write-Host "Launch"
    Write-Host -NoNewline "3. " -ForegroundColor $MenuNumColor
    Write-Host "Open game folder"
    Write-Host -NoNewline "4. " -ForegroundColor $MenuNumColor
    Write-Host "View patch notes"
    Write-Host -NoNewline "5. " -ForegroundColor $MenuNumColor
    Write-Host "Close launcher"
    Write-Host ""
}

while ($true) {
    Show-Menu
    $choice = Read-Host "Choice"

    switch ($choice) {
        "1" {
            Write-Host ""
            if ($DownloadUrl -like "*example.com*") {
                Write-Host "No real download link is set yet." -ForegroundColor $ErrColor
                Write-Host "" -ForegroundColor $ErrColor
                Read-Host "Press Enter to continue"
                continue
            }
            $targetFolder = Split-Path -Path $GamePath -Parent
            if (-not (Test-Path $targetFolder)) {
                New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
            }

            Write-Host "Downloading..." -ForegroundColor $BorderColor

            try {
                $global:dlCompleted = $false
                $global:dlError = $null
                $wc = New-Object System.Net.WebClient

                Register-ObjectEvent -InputObject $wc -EventName DownloadProgressChanged -SourceIdentifier dlProgress -Action {
                    $percent = $EventArgs.ProgressPercentage
                    Write-Host -NoNewline "`rDownloading... $percent%   "
                } | Out-Null

                Register-ObjectEvent -InputObject $wc -EventName DownloadFileCompleted -SourceIdentifier dlCompleted -Action {
                    if ($EventArgs.Error) { $global:dlError = $EventArgs.Error.Message }
                    $global:dlCompleted = $true
                } | Out-Null

                $wc.DownloadFileAsync([Uri]$DownloadUrl, $GamePath)

                while (-not $global:dlCompleted) {
                    Start-Sleep -Milliseconds 150
                }

                Unregister-Event -SourceIdentifier dlProgress
                Unregister-Event -SourceIdentifier dlCompleted
                $wc.Dispose()
                Write-Host ""

                if ($global:dlError) {
                    Write-Host "Download failed:" -ForegroundColor $ErrColor
                    Write-Host $global:dlError -ForegroundColor $ErrColor
                } else {
                    Write-Host "Download complete (100%)." -ForegroundColor $OkColor
                    Write-Host "Saved to: $GamePath"
                }
            } catch {
                Write-Host ""
                Write-Host "Download failed:" -ForegroundColor $ErrColor
                Write-Host $_.Exception.Message -ForegroundColor $ErrColor
            }
            Read-Host "Press Enter to continue"
        }
        "2" {
            Write-Host ""
            if (Test-Path $GamePath) {
                Write-Host "Launching..." -ForegroundColor $OkColor
                Start-Process $GamePath
            } else {
                Write-Host "Executable not found. Check `$GamePath in the script." -ForegroundColor $ErrColor
            }
            Read-Host "Press Enter to continue"
        }
        "3" {
            Write-Host ""
            if (Test-Path $GamePath) {
                $folder = Split-Path -Path $GamePath -Parent
                Write-Host "Opening folder..." -ForegroundColor $BorderColor
                Start-Process "explorer.exe" $folder
            } else {
                Write-Host "Folder not found." -ForegroundColor $ErrColor
            }
            Read-Host "Press Enter to continue"
        }
        "4" {
            Write-Host ""
            Write-Host "Sorry, the game hasn't been released yet." -ForegroundColor $ErrColor
            Read-Host "Press Enter to continue"
        }
        "5" {
            Write-Host ""
            Write-Host "See you soon!" -ForegroundColor "Magenta"
            Start-Sleep -Seconds 1
            exit
        }
        default {
            Write-Host "Invalid choice." -ForegroundColor $ErrColor
            Start-Sleep -Seconds 1
        }
    }
}
